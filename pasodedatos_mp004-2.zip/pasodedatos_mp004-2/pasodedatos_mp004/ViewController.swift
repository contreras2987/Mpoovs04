//
//  ViewController.swift
//  pasodedatos_mp004
//
//  Created by Usuario invitado on 2/14/19.
//  Copyright © 2019 Usuario invitado. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var labelDatos: UILabel!
    var dato: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
        labelDatos.text = dato
    }
    //segue sabe el origen y destino
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "toSecondView"{
            let secondView = segue.destination as? SecondvViewController
            secondView?.dato = "hola mundo"
            secondView? .backView = self
        }
    }
    
}


