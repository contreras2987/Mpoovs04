//
//  SecondvViewController.swift
//  pasodedatos_mp004
//
//  Created by Carlos uriel on 2/14/19.
//  Copyright © 2019 Usuario invitado. All rights reserved.
//

import UIKit

class SecondvViewController: UIViewController {
    
    
    @IBOutlet weak var etiqueta: UILabel!
    
    
    @IBOutlet weak var caja: UITextField!
    
    var backView:ViewController?
    
    
    var dato: String = ""
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = .blue   //cambio de color a la vista
        
        etiqueta.text = dato
        caja.text = dato
        
    }
    
    
    
    @IBAction func regreso(_ sender: Any) {
    
    

            if let bcView = backView{
            if let texto = caja.text{
                bcView.dato = texto
                self.dismiss(animated: false, completion: nil)
            }
        }
    }
    
}

