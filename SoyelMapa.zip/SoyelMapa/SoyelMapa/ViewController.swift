//
//  ViewController.swift
//  SoyelMapa
//
//  Created by Macbook on 5/2/19.
//  Copyright © 2019 UK. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation


class ViewController: UIViewController,CLLocationManagerDelegate {
    
    
    

    @IBOutlet weak var mapa: MKMapView!
    var manager = CLLocationManager()
    var latitud = CLLocationDegrees()
    var longitud = CLLocationDegrees()
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        manager.delegate = self
     manager.requestWhenInUseAuthorization() //Permisos de ubicacion
         manager.desiredAccuracy = kCLLocationAccuracyBest
        
     manager.startUpdatingLocation()//la localizacion del celular
    }
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let location = locations.first{
            self.longitud =  location.coordinate.latitude
            self.latitud = location.coordinate.longitude
        }
    }
    
    @IBAction func getCoords(_ sender: UIButton) {
        print(longitud,latitud)
        let localizacion = CLLocationCoordinate2D(latitude: latitud, longitude: longitud)
        let span = MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)
        let region = MKCoordinateRegion(center: localizacion
            , span: span)
        mapa.setRegion(region, animated: true)
        mapa.showsUserLocation = true
    }
    

}

