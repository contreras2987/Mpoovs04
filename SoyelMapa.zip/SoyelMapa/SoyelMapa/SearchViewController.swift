//
//  SearchViewController.swift
//  SoyelMapa
//
//  Created by Macbook on 5/2/19.
//  Copyright © 2019 UK. All rights reserved.
//

import UIKit
import MapKit

class SearchViewController: UIViewController, UISearchBarDelegate {
    @IBOutlet weak var buscar: UISearchBar!
    
    @IBOutlet weak var mapa: MKMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        buscar.delegate = self

        // Do any additional setup after loading the view.
    }
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        buscar.resignFirstResponder()
       
        let geocoder = CLGeocoder()
        
        geocoder.geocodeAddressString(buscar.text!){(places:[CLPlacemark]?,error:Error?) in
            
            
            
            if let error = error {
                
                print(error.localizedDescription)
                
            }else{
               let place = places?.first
                let anotacion = MKPointAnnotation()
                anotacion.coordinate = (place?.location?.coordinate)!
                anotacion.title = self.buscar.text
                let span = MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)
                let region = MKCoordinateRegion(center: anotacion.coordinate, span: span)
                self.mapa.setRegion(region,animated : true)
                self.mapa.addAnnotation(anotacion)
                self.mapa.selectAnnotation(anotacion, animated: true)
                
            }
            
            
        }
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
