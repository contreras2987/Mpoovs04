//
//  ViewController.swift
//  pots
//
//  Created by Macbook on 3/28/19.
//  Copyright © 2019 Theranos. All rights reserved.
//

import UIKit
import Lottie
class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        let animacion = LOTAnimationView(name: "5135-cadena")
        animacion.loopAnimation = true
        animacion.frame = view.frame
        self.view.addSubview(animacion)
        animacion.play()
        
    }


}

