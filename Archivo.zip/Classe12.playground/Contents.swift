import UIKit
import PlaygroundSupport

struct Results: Codable{
    
    var resultCount: Int
    var results:[Track]
    
}
struct Track Codable {
    var trackName: String
    
}

let url = URL(string: "https://itunes.apple.com/search?term=mecano")
///objeto del tipo el metodo
let jsonDecoder = JSONDecoder()


let Task = URLSession.shared.dataTask(with: url!) { (data, response, error) in{
    if  let data  = data,let resultado = try? jsonDecoder.decode(Results.self,from:data){
        print(resultado.resultCount)
        
        for track in resultado.results{
            
        print(track.trackName)
        }
        
        //let string = String(data: data, encoding: .utf8){
        
        ///print(string)
    }
}
    
Task.resume()

///para ejecutarlo varias veces

PlaygroundPage.current.needsIndefiniteExecution = true

