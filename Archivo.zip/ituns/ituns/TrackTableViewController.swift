//
//  TrackTableViewController.swift
//  ituns
//
//  Created by Macbook on 3/21/19.
//  Copyright © 2019 Theranos. All rights reserved.
//

import UIKit
class TrackTableViewController: UITableViewController {
    var tracks:[String]=[]
    
override func viewDidLoad() {
     super.viewDidLoad()
        tableView.backgroundColor = .red
    getTracks()
        
    }
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section:Int)-> Int{
        return tracks.count
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celda",for: indexPath)
        cell.textLabel!.text = tracks[indexPath.row]
        return cell
    }
   
    
    func getTracks(){
        let url = URL(string: "https://itunes.apple.com/search?term=mecano")
        ///objeto del tipo el metodo
        let jsonDecoder = JSONDecoder()
        let Task = URLSession.shared.dataTask(with: url!) { (data, response, error) in
            if  let data  = data,let resultado = try? jsonDecoder.decode(Results.self,from:data){
            print(resultado.resultCount)
            
            for track in resultado.results{
                
                print(track.trackName)
                self.tracks.append(track.trackName)
            }
            
            //let string = String(data: data, encoding: .utf8){
            
            ///print(string)
            DispatchQueue.main.async{
                self.tableView.reloadData()
            }
        }
        }
        Task.resume()
        }
    
}

