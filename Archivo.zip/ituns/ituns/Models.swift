//
//  Models.swift
//  ituns
//
//  Created by Macbook on 3/21/19.
//  Copyright © 2019 Theranos. All rights reserved.
//
import UIKit
struct Results: Codable{
    
    var resultCount: Int
    var results:[Track]
    
}
struct Track: Codable {
    var trackName: String
    
}

