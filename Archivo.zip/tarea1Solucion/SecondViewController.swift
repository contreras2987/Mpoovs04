//
//  SecondViewController.swift
//  tarea1Solucion
//
//  Created by macbook on 2/19/19.
//  Copyright © 2019 brett,aaron. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {
    
    var controller1: ViewController!
    
    @IBOutlet weak var etiqueta: UILabel!
    
    var datoDesdeVista1: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        etiqueta.text = datoDesdeVista1
        
    }
    
    @IBAction func regresar(_ sender: UIButton) {
    controller1.deSegundaVista = "Saludis desde Visata 2"
        dismiss(animated: true, completion: nil)
    }
    
    

}
