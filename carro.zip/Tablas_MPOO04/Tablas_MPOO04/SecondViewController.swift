
import UIKit

class SecondViewController: UIViewController {

    @IBOutlet weak var nombre: UILabel!
      @IBOutlet weak var imagen: UIImageView!
    @IBOutlet weak var precio: UILabel!
    @IBOutlet weak var descripcion: UITextView!
    @IBOutlet weak var NOproductos: UILabel!

    var viewcontroller: ViewController!
    var dato: String = ""
    var descripciones : String = ""
    var pt: String = ""
    var po : Int = 0
    var numeroP: String = ""
    var numeroPINT: Int = 0
    var precioConjunto: String = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        descripcion.text = descripciones
        precio.text = pt
        imagen.image = UIImage(named: dato)
        nombre.text = dato
    }
    
   
    
    @IBAction func cerrar(_ sender: UIButton){
        dismiss(animated: true, completion: nil)
    }

    @IBAction func sumaResta(_ sender: UIStepper) {
        print(sender.value)
        numeroPINT = Int (sender.value)
        numeroP = "\(numeroPINT)"
        NOproductos.text = numeroP
        
    }
    
    
    @IBAction func comprar(_ sender: UIButton){
        if let previusView = viewcontroller as? ViewController{
            po = po*numeroPINT
            previusView.carro += po
            previusView.todo += numeroPINT
        }
        
        dismiss(animated: true, completion: nil)
    }
    
}
