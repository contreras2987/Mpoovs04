

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate{
    var carro : Int = 0
    @IBOutlet weak var precioActual: UILabel!
    @IBOutlet weak var totalProductos: UILabel!
    @IBOutlet weak var tabla: UITableView!
    
    var dulces: [String] = []
    var descripcion1: [String] = ["chocolate cubierto de almendras","dulce de cacahuate","galleta cubierta de chocolate"]
    var preciotexto: [String] = ["$8","$5","$13"]
    var precioOperable: [Int] = [8,5,13]
    var todo : Int = 0
    var todotxt : String = ""
    var carritotxt: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        dulces = ["Ferrero", "mazapan", "kitkat"]
        
        
    }
    override func viewWillAppear(_ animated: Bool) {
        print(carro)
        carritotxt = "\(carro)"
        todotxt = "\(todo)"
        totalProductos.text = todotxt
        precioActual.text = carritotxt
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dulces.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: "celda"){
        
        //cell.backgroundColor = .blue
        cell.textLabel!.text = dulces[indexPath.row]
        cell.imageView!.image = UIImage(named: dulces[indexPath.row])
        
        return cell
        }
        return UITableViewCell()
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        let indexPath = tabla.indexPathForSelectedRow
        let secondView = segue.destination as? SecondViewController
        secondView?.dato = dulces[(indexPath?.row)!]
        secondView?.descripciones = descripcion1[(indexPath?.row)!]
        secondView?.po = precioOperable[(indexPath?.row)!]
        secondView?.pt = preciotexto[(indexPath?.row)!]
        secondView?.viewcontroller = self
    }
    

}

