import UIKit

func sumar (numeros: [Int]) -> Int {
    var total = 0
    for numero in numeros{
        total += numero
    }
    return total
}
let testNumeros = [1,2,3,4,5,6,7,8,9]
print(sumar (numeros: testNumeros))

let sumaClosure = { (numeros: [Int])-> Int in
    var total = 0
    for numero in numeros{
        total += numero
    }
    return total
    
}
let resultado = sumaClosure(testNumeros)

//tipos de closures

let printClosure = { () -> Void in
    print("Este closure no regresa nada")
    
}

let printClosure2 = { (cadena: String )-> Void in
    print(cadena)
}

let printClosure3 = { ()-> Int in
    return 5
}
let printClosure4 = { (cadena1: String, cadena2: String)-> String in
    return cadena1 + cadena2
}

var arreglo = ["Hola", "adiosito", "que tal","bye"]
let arregloOrdenado = arreglo.sorted { (cadena1, cadena2)-> Bool in
    return cadena1.count > cadena2.count
}

print(arregloOrdenado)

struct alumno{
    var id: Int
    var nombre: String
}

var alumnos: [alumno] = [
    alumno(id: 2, nombre: "jose"),
    alumno(id: 1, nombre: "pepe"),
    alumno(id: 7, nombre: "luis"),
    alumno(id: 5, nombre: "daniel")
]
let arreOrd = alumnos.sorted { (cade1, cade2) -> Bool in
    return cade1.nombre > cade2.nombre
}
print(arreOrd)

//let Orde = alumnos.sorted{ (alumnos, alumnos) -> Bool in
  //  return alumno.count > alumno.count
    
//}
