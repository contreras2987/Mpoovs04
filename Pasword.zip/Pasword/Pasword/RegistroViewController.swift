//
//  RegistroViewController.swift
//  Pasword
//
//  Created by Macbook on 2/28/19.
//  Copyright © 2019 Biblioteca. All rights reserved.
//

import UIKit

class RegistroViewController: UIViewController {

    @IBOutlet weak var nombre: UITextField!
    
    @IBOutlet weak var contraseña: UITextField!
    
    @IBOutlet weak var confirmarContraseña: UITextField!
   
  
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    @IBAction func botonReg(_ sender: Any) {
    
        let  Nombre = nombre.text;
        let Cont = contraseña.text;
       // let  conf = confirmarContraseña.text;
    

    UserDefaults.standard.set(Nombre , forKey: "nombre")
    UserDefaults.standard.set(Cont, forKey: "contraseña")
    UserDefaults.standard.synchronize()
    
    self.dismiss(animated: true, completion: nil)
    }
}
    
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


