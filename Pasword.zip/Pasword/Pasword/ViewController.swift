//
//  ViewController.swift
//  Pasword
//
//  Created by Macbook on 2/28/19.
//  Copyright © 2019 Biblioteca. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    override func viewDidAppear(_ animated: Bool) {
        let inicio = UserDefaults.standard.bool(forKey: "inicio");
        if(!inicio)
        {
            self.performSegue(withIdentifier: "fin", sender: self)
            
        }
    }
    
    @IBAction func salir(_ sender: Any) {
    
    UserDefaults.standard.set(false, forKey: "inicio")
    UserDefaults.standard.synchronize()
    self.performSegue(withIdentifier: "fin", sender: self)

    }

}

