//
//  ViewController.swift
//  Clima
//
//  Created by Macbook on 4/5/19.
//  Copyright © 2019 Sauzun. All rights reserved.
//

import UIKit
var clima:[String] = []
class ViewController: UIViewController {
    @IBOutlet weak var FondoDePantalla: UIImageView!
    
    @IBOutlet weak var ciudad: UILabel!
    
    @IBOutlet weak var temperatura: UILabel!
    
    @IBOutlet weak var Fecha: UILabel!
    
    @IBOutlet weak var Zona: UILabel!
    
    @IBOutlet weak var zonaHoararia: UILabel!
    
    @IBOutlet weak var clima: UILabel!
    
    
     var Clima:Data!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view, typically from a nib.
        getClima()
    }
    func getClima(){
        let url = URL(string: "https://api.weatherbit.io/v2.0/current?city=Mexico,Mx&key=96ba6dd0344e4f83af551a6c92cd1136")
        
        let jsonDecoder = JSONDecoder()
        
        let tarea = URLSession.shared.dataTask(with: url!){ (data, response, error) in
            
            if let data = data, let results = try? jsonDecoder.decode(Results.self, from: data){
                print("Hola")
                for dataKey in results.data{
                    print(dataKey.temp)

                DispatchQueue.main.async {
                   
                    self.Zona.text = dataKey.timezone
                    self.Fecha.text = String(dataKey.datetime)
                    self.ciudad.text = dataKey.city_name
                    self.clima.text = dataKey.weather.description
                    self.temperatura.text = "La temperatura es: \(dataKey.temp)" + " ºC"
                  ///  self.elegirImagen(icon: dataKey.weather.icon)
                    self.elegirFondo(temp: dataKey .temp )
                
                    }
                }
            }
            
        }
          tarea.resume()
    }
        
    func elegirFondo(temp: Double){
                
                if (temp == 0){
                     FondoDePantalla.image = UIImage (named: "Invierno")
                }else if (temp == 0 || temp <= 10){
                   FondoDePantalla.image = UIImage (named: "Templado")
                }else if (temp == 11 || temp <= 20){
                    
                    //self.fondoClimaView.image = UIImage (named: "sun2")
                }else if (temp == 21 || temp <= 25){
                        FondoDePantalla.image = UIImage (named: "Soleado")
                }else if (temp > 25){
                    FondoDePantalla.image = UIImage (named: "Soleado-1")
    

        }
        }
        

}



