//
//  ViewController.swift
//  Clima
//
//  Created by Macbook on 4/5/19.
//  Copyright © 2019 Sauzun. All rights reserved.
//

import UIKit
var clima:[String] = []
class ViewController: UIViewController {
    @IBOutlet weak var ciudadTextField: UITextField!
    @IBOutlet weak var ciudad: UILabel!
    
    @IBOutlet weak var temperatura: UILabel!
    
    @IBAction func clima(_ sender: Any) {
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view, typically from a nib.
        getClima()
    }
    func getClima(){
        let url = URL(string: "https://api.weatherbit.io/v2.0/current?city=Cuernavaca,Mx&key=96ba6dd0344e4f83af551a6c92cd1136")
        
        let jsonDecoder = JSONDecoder()
        
        let tarea = URLSession.shared.dataTask(with: url!) { (data, response, error) in
            
            if let data = data, let results = try? jsonDecoder.decode(ClimaStruct.self, from: data){
                DispatchQueue.main.async {
                    self.ciudad.text = results.data[0].city_name
                    
                    self.temperatura.text = "\(results.data[0].temp)"
                }
            }
                
            }.resume()

    }

}
