//
//  Modelos.swift
//  ClimaProyecto
//
//  Created by Macbook on 4/1/19.
//  Copyright © 2019 Theranos. All rights reserved.
//

import UIKit

struct Results: Codable {
    var data: [Data]
}
struct Data: Codable {
    var timezone: String
    var datetime: String
    var city_name: String
    var weather: weatherData
    var temp: Double
}
struct weatherData: Codable {
    var icon: String
    var description: String
}
