//
//  Climas.swift
//  Clima
//
//  Created by Macbook on 4/5/19.
//  Copyright © 2019 Sauzun. All rights reserved.
//

import Foundation

struct ClimaStruct: Codable{
    var data: [ClimaData]
}
struct ClimaData: Codable{
    var city_name: String
    var temp: Double
}
