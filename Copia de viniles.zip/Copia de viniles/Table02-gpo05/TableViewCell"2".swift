//
//  TableViewCell"2".swift
//  Table02-gpo05
//
//  Created by macbook on 06/04/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit

class TableViewCell_2_: UITableViewCell {

    @IBOutlet var cantidadLabel: UILabel!
    @IBOutlet var precioLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
