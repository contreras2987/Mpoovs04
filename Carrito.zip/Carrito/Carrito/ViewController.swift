//
//  ViewController.swift
//  Carrito
//
//  Created by Raúl Gustavo Saucedo Zuñiga on 3/11/19.
//  Copyright © 2019 kamikaze. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate { /*Declaración de Protocolos para poder trabajar con la TableView */
    
  

    //Implementación de métodos obligatorios, los cuales harán que la tabla, muestre los datos que pretendmos
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return productos.count //count devuelve la cantidad de elementos de nuestro arreglo
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
    
        if let celda1 = tableView.dequeueReusableCell(withIdentifier: "celdaProductos"){
        
        //Como celda1 es un objeto, se le asigna a la propiedad textLabel el texto que se pretende, es decir lo que contiene el elemento de acuerdo al indexPath.row
        celda1.textLabel?.text = productos[indexPath.row]
        celda1.imageView!.image = UIImage(named: productos[indexPath.row])!
        
        return celda1
        }
        return UITableViewCell()
    }
    
    var productos: [String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        productos = ["Pan", "Dulces", "Frituras", "Refrescos"]
    
    }


}

