//
//  SecondViewController.swift
//  Carrito
//
//  Created by Macbook on 3/12/19.
//  Copyright © 2019 kamikaze. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    @IBOutlet weak var NomProd: UILabel!
    
    var dato: String = ""
    var precio: Float
    
    override func viewDidLoad() {
        super.viewDidLoad()
        NomProd.text = dato

        
    }
    

    }

    
