//
//  ViewController.swift
//  Unam
//
//  Created by Macbook on 4/4/19.
//  Copyright © 2019 ClaseMPOO. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth

class ViewController: UIViewController {

    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var password: UITextField!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
 
    @IBAction func registerUser(_ sender: UIButton) {

}



