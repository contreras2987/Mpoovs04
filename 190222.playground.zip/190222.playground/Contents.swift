import UIKit
///RELACION DE USO
class Dulce{///cuandi estamos  trabajaodes tenemos que hacer  nuestras inicianilaciacicioens
    var nombre: String
    var precio:Float
    var gramos:Int
    init(nombre:String,precio:Float,gramos:Int ) {
        self.nombre = nombre
        ///Instanicias de la clase
        self.precio = precio
    //las clases
        self.gramos = gramos
        
 // constructor se utiliza para incializar metodos y propiedades 
    }
}
class Pan :Dulce  {
 ///la erenica nos permitemen reeecribir lo que heredamos
var delDia:Bool
    //referencia a la clase padre///override sobree escribir
    
    ///PADRE
override init(nombre: String, precio: Float, gramos: Int) {
        self.delDia = true
        super.init(nombre: nombre, precio: precio, gramos: gramos)
    }
 //HIJO
    
    init(nombre: String, precio: Float, gramos: Int,delDia:Bool) {
        self.delDia = delDia
        super.init(nombre: nombre, precio: precio, gramos: gramos)
}
///agregando dulces a la clase / los valores de la clase no se mueven

//UML Relacion de uso
class caja {
   ///Relacion de uso/UNA INYEECCION ESTAMOS LLAMOS UN CLASE A OTRA/LA CLASES IGNORA COMO VIENE /Iyectar un clase//
    let dulce :[Dulce]
    init(dulce:[Dulce]) {
        self.dulce = dulce
        
    }
    func getTotal() -> Float{
        var total : Float = 0.0
        for dulce in dulce{
            total += dulce.precio
        
    }
        return total
    }
}
let pulparindo = Dulce (nombre: "pulparindo ", precio: 4.00, gramos: 5)
let paleta = Dulce (nombre: "Paleta", precio: 10.00, gramos: 5)
let dona = Pan(nombre: "Dona", precio: 30, gramos: 50)
let dona = conc(nombre: "Dona", precio: 30, gramos: 50)


var arregloDulces = [pulparindo, paleta]
let Caja = caja(dulce: arregloDulces)
Caja.getTotal()
